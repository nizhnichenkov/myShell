/**
 * @author          Svetoslav Nizhnichenkov
 * @StudentID       17712081
 * @email           svetoslav.nizhnichenkov@ucdconnect.ie
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include "functions.h"
#define BUFFSIZE 1024


int main(int argc, char **argv)
{
    // call shell
    shell_loop();

    return EXIT_SUCCESS;
}
